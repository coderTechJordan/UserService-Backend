// NewPassword.java
package com.example.UserService.model;

public class NewPassword {
    private String newPassword;

    // Getters and setters
}
