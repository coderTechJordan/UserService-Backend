// UserIdentification.java
package com.example.UserService.model;

public class UserIdentification {
    private String email;

    // Getters and setters
}