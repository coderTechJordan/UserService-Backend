package com.example.UserService.controller;

import com.example.UserService.dynamodb.PutUserItem;
import com.example.UserService.model.*;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    // Placeholder list to simulate a database
    private final List<User> userList = new ArrayList<>();

    @PostMapping
    public User createUser(@RequestBody User user) {
        // Placeholder logic to save the user to a database
        userList.add(user);

        // Call the method to put the user item in DynamoDB
        PutUserItem putUserItem = new PutUserItem();
        putUserItem.execute(new String[]{"jordan-user-service", user.getId().toString(), user.getUsername(), user.getPassword(), user.getEmail(), user.getCreatedAt()});

        // Return the created user
        return user;
    }

    @GetMapping
    public List<User> listUsers() {
        // Return the list of users (simulated from the userList)
        return userList;
    }

    @GetMapping("/{userId}")
    public User getUserById(@PathVariable Long userId) {
        // Placeholder logic to retrieve a user by ID from the database (simulated from the userList)
        return userList.stream()
                .filter(u -> u.getId().equals(userId))
                .findFirst()
                .orElse(null);
    }

    @PutMapping("/{userId}")
    public User updateUser(@PathVariable Long userId, @RequestBody User updatedUser) {
        // Placeholder logic to update a user by ID in the database (simulated from the userList)
        userList.removeIf(u -> u.getId().equals(userId));
        userList.add(updatedUser);
        // Return the updated user
        return updatedUser;
    }

    @DeleteMapping("/{userId}")
    public void deleteUser(@PathVariable Long userId) {
        // Placeholder logic to delete a user by ID from the database (simulated from the userList)
        userList.removeIf(u -> u.getId().equals(userId));
    }

    // Other endpoint methods for authentication, password change, etc.
}
