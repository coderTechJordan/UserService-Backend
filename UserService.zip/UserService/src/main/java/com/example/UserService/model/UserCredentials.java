// UserCredentials.java
package com.example.UserService.model;

public class UserCredentials {
    private String username;
    private String password;

    // Getters and setters
}